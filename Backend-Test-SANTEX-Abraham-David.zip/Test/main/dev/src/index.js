const express =  require('express');
const {database} = require('./config/env');
const path = require('path');
// Init

const app = express();

app.set('port', process.env.PORT || 4000);

// Middleware
app.use(express.urlencoded({extended: false}));
app.use(express.json());

//Routes

app.use(require('./routes/import-league.route'));

// Public

app.use(express.static(path.join(__dirname, 'public')));

// Turn the server ON

app.listen(app.get('port'), () => {
    console.log('Server Running on port ', app.get('port'));
})