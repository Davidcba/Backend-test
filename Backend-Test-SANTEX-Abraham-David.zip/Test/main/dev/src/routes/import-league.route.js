const express = require ('express');
const router = express.Router();
const {importLeague} = require('../controllers/import-league.controller');

router.get('/import-league/:leagueCode', importLeague);

module.exports  = router;