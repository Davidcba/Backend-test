const express = require ('express');
const router = express.Router();

const allLeaguePlayers = require('../controllers/total-players.controller')

router.get('/total-players/:leagueCode', allLeaguePlayers);

module.exports  = router;