const sequelize = require('../../config/sequelize-config');
const DataTypes = require('sequelize');

module.exports = function () {
    return sequelize.define('competition', {
        id: {
            type: DataTypes.INTEGER,
            field: 'id',
            unique: true,
        },
        name: {
            type: DataTypes.STRING,
            field: 'name'
        },
        code: {
            type: DataTypes.STRING,
            field: 'code'
        },
        areaName: {
            type: DataTypes.STRING,
            field: 'areaName',
            primaryKey: true,
        }

    }, { tableName: 'competition',
            timeStamp: false,
        }
        )

}