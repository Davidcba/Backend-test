const sequelize = require('../../config/sequelize-config');
const DataTypes = require('sequelize');

module.exports = function () {
    return sequelize.define('players', {
            id_player: {
                type: DataTypes.INTEGER,
                field: 'id_player',
                unique: true,
            },
            id_team: {
                type: DataTypes.INTEGER,
                field: 'id_team',
                unique: true,
                primaryKey: true,
            },
            name: {
                type: DataTypes.STRING,
                field: 'name'
            },
            position: {
                type: DataTypes.STRING,
                field: 'position'
            },
            nationality: {
                type: DataTypes.STRING,
                field: 'nationality',

            },
            dateOfBirth: {
                type: DataTypes.STRING,
                field: 'dateOfBirth',

            },
            countryOfBirth: {
                type: DataTypes.STRING,
                field: 'countryOfBirth',

            },
            areaName: {
                type: DataTypes.STRING,
                field: 'areaName',

            }
        }, { tableName: 'players',
            timeStamp: false,
        }
    )

}