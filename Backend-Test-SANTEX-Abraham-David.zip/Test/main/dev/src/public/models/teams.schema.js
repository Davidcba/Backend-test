const sequelize = require('../../config/sequelize-config');
const DataTypes = require('sequelize');

module.exports = function () {
    return sequelize.define('teams', {
        id_team: {
            type: DataTypes.INTEGER,
            field: 'id_team',
            unique: true,
        },
        name: {
            type: DataTypes.STRING,
            field: 'name'
        },
        tla: {
            type: DataTypes.STRING,
            field: 'tla'
        },
        shortName: {
            type: DataTypes.STRING,
            field: 'shortName',
        },
        areaName: {
            type: DataTypes.STRING,
            field: 'areaName',
            primaryKey: true,
        },
        email: {
            type: DataTypes.STRING,
            field: 'email',
        }

    }, { tableName: 'teams',
         timeStamp: false,
        }
        )

}