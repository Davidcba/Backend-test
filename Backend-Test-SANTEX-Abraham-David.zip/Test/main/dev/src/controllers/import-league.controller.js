const players = require('../public/models/player.schema');
const competition = require('../public/models/competition.schema');
const teams = require('../public/models/competition.schema');
const leagueController  = {};
const authToken = 'b58b9c93351a4e8884ec9649bba4280a';
let request = require('request');
let competition_area ;
let my_competition;
let my_league_teams;
let delay = 60000;// 60 Seconds
let total_players;
leagueController.importLeague = (req, res, next) => {
    let leagueCode = req.params.leagueCode;
    /// Check if the league code exists
    competition.findOne({
        where:{
            code: leagueCode
        }
    }).then(
        res.status(409).send('League already imported'),
        next()
    )


    // GET COMPETITIONS FROM API
    request.get({
        headers: {'X-Auth-Token': authToken},
        url: "http://api.football-data.org/v2/competitions",
    }, (error, response,body) => {
        if(error) {

            return res.status(504).send('Server Error');
        }
        let competition = JSON.parse(body);
        let comp_arr = competition.competitions;
        let obj = comp_arr.find(obj => obj.code === leagueCode);
        let my_league_data;
        if (obj) {
             my_league_data = {
                name: obj.name,
                code: obj.code,
                areaName: obj.area.name
            }
        }
        else{
            res.status(404)
                .send('League Not found ')
        }
        my_competition = my_league_data;
        competition_area = my_league_data.areaName;
    })

    // GET TEAMS FOR COMPETITION
    let teams_link = "https://api.football-data.org/v2/competitions/"+leagueCode+"/teams"
    request.get({
        headers: {'X-Auth-Token': authToken},
        url: teams_link,
    }, (error, response,body) => {
        if(error) {
            return res.status(504).send('Server Error');
        }
        let teams = JSON.parse(body);
        let team_arr = teams.teams;
        const my_Teams = team_arr.map(({id,name, tla, shortName, area, email }) =>{
            return { id: id,name: name, tla: tla, shortName: shortName, areaName: area.name, email: email};
        })
        let the_length = my_Teams.length ;
        my_league_teams = my_Teams;
        for(let i=0; i< the_length ;i++){
            let players_link = 'https://api.football-data.org/v2/teams/'+my_Teams[i].id;
            request.get({
                headers: {'X-Auth-Token': authToken},
                url: players_link,
            }, (error, response,body) => {
                if(error) {
                    return res.status(504).send('Server Error');
                }
                let team = JSON.parse(body);
                let arr_players = team.squad;
                let my_arr_players;
                if (arr_players === undefined){

                    setTimeout(function() {
                        my_arr_players = arr_players.map(({name, position, dateOfBirth, countryOfBirth, nationality }) => {
                            return {
                                name: name,
                                position: position || 'COACH',
                                dateOfBirth: dateOfBirth,
                                countryOfBirth: countryOfBirth,
                                nationality: nationality,
                                areaName: my_competition.areaName,
                            };
                        });
                    }, delay);
                } else {
                    my_arr_players = arr_players.map(({name, position, dateOfBirth, countryOfBirth, nationality }) => {
                    return {
                        name: name,
                        position: position || 'COACH',
                        dateOfBirth: dateOfBirth,
                        countryOfBirth: countryOfBirth,
                        nationality: nationality,
                        areaName: my_competition.areaName,
                    };
                });}
                let prev_total_players = total_players;
                total_players =  [...prev_total_players, ...my_arr_players];

            })



        }});

        /// Load Data Into the DB
        try {
            competition.create(my_competition);
            teams.bulkCreate(my_league_teams);
            let only_players = total_players.filter(o => o.position !== 'COACH');
            players.bulkCreate(only_players);
            res.status(201).send('Successfully imported')
        }
        catch (e) {
            res.status(504).send('Server Error')
        }




};

module.exports = leagueController;