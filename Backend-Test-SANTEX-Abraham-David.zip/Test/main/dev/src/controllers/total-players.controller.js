const players = require('../public/models/player.schema');
const competition = require('../public/models/competition.schema');
const teams = require('../public/models/competition.schema');
const leagueService = {};
let my_players;
let my_teams;
let comp;
let my_code;

leagueService.allLeaguePlayers =(req, res, next) => {
    my_code = req.params.leagueCode;
    competition.findOne({
        where:{
            code: my_code
        }
    }). then(
        my_comp =>{
            if (my_comp){
             comp = my_comp;
            }
            else {
                res.status(404).send('Competition Not Found')
            }
        }
    )

    if (comp !== undefined) {
        teams.findAll({
            where:{
                areaName: comp.areaName
            }
        }).then(
            teams => {
                if (teams){
                    my_teams = teams;
                }
                else {
                    res.status(404).send('No teams Found')
                }
            }
        )


    }
    if (my_teams !== undefined) {

        players.findAll({
            attributes: { exclude: ['id_player'] }
        }).then(all_players =>{
                if(all_players){
                    my_players = all_players.filter(o => obj.areaName === my_code)

                    res.status(201).send(JSON.stringify(my_players));
                }
                else {
                    res.status(404).send('No data found')
                }
            }

        )
    }

}
module.exports = leagueService;